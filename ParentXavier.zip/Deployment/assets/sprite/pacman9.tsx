<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="pacman9" tilewidth="8" tileheight="8" tilecount="868" columns="28">
 <image source="pacman9.png" width="224" height="248"/>
</tileset>
